#############################################################################################
# Filename: Data_Collection_Preparation_2020_v2.R
#
# Author: Fabian Schipfer (FS)
# Created: 01-Aug-2018
#
# Version: 1.0
# 
# Changed on 23-Jun-2020 by FS
#         reason: update & resubmission as data in brief in Energy
# Changed on: 15-Jan-2020 by FS
#         reason: update & resubmission as data in brief in Energy
# Changed on: 11-Mar-2019 by FS
#         reason: update & resubmission at Commodity Markets
# Run on: R-Studio Version 1.3.959 running the R version 4.0.2 (2020-06-22)
#############################################################################################
#
# All calculations, graphics and tables presented in manuscript
#
#
# Data files required:   none
# Subfunctions:          none
# R-files required:      none
# other files:           none
# Problems:              none
#############################################################################################
#
# Part 1
#
# download (wood pellet) data from Eurostat and save in an R-data file
#############################################################################################

rm(list=ls())
setwd("~/Submissions/Commoditisation/Submission2020/Resubmission/Datainbrief_v2")


require(rsdmx)
require(XML)

##Country codes used by Eurostat
#erostateu28<-c("AT","BE","BG","CY","CZ","DE","DK","EE","ES","FI","FR","GB","GR","HR","HU","IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK")

#selected countries for the analysis (all but SE)
folge<-c("AT","IT","DE","FR","SE")

##Create data format for saving Eurostat data
allflows<-data.frame(PARTNER=NA,FLOW=NA,INDICATORS=NA,PRODUCT=NA,REPORTER=NA,FREQ=NA,obsTime=NA,obsValue=NA,OBS_STATUS=NA)
dataset<-c("physimp","physexp","monimp","monexp")

df<-data.frame(name=dataset,
               flow=c(1,2,1,2),
               unit=c("QUANTITY_IN_100KG","QUANTITY_IN_100KG","VALUE_IN_EUROS","VALUE_IN_EUROS"))

##dataURL has to be modified for each product
##see https://webgate.ec.europa.eu/fpfis/mwikis/sdmx/index.php/Main_Page


dataURL1<-rep("",28)
dataURL2<-rep("",28) #since 2020 each country dataset has to be split in 2 downloads due to the limitations of Eurostat 
for(d in 1:4){
  for(c in 1:5){
    dataURL1[c] <- paste("http://ec.europa.eu/eurostat/SDMX/diss-web/rest/data/DS-016893/M.",folge[c],"..440131.",df$flow[d],".",df$unit[d],"?startperiod=2012&endPeriod=2016",sep="")
    dataURL2[c] <- paste("http://ec.europa.eu/eurostat/SDMX/diss-web/rest/data/DS-016893/M.",folge[c],"..440131.",df$flow[d],".",df$unit[d],"?startperiod=2017&endPeriod=2020",sep="")
    sdmx1 <- readSDMX(dataURL1[c])
    sdmx2 <- readSDMX(dataURL2[c])
    stats1 <- as.data.frame(sdmx1)
    stats2 <- as.data.frame(sdmx2)
    available1<-c(stats1$OBS_STATUS=="na")
    available2<-c(stats2$OBS_STATUS=="na")
    available1[is.na(available1)]<-FALSE
    available2[is.na(available2)]<-FALSE
    stats1<-stats1[!available1,]
    stats2<-stats2[!available2,]
    allflows<-rbind(allflows,stats1)
    allflows<-rbind(allflows,stats2)
  }
  allflows<-allflows[2:dim(allflows)[1],]
  saveRDS(allflows,file=paste(df$name[d],strtrim(Sys.time(),10),".rds",sep="")) #,format(Sys.time(), "%Y")
  allflows<-data.frame(PARTNER=NA,FLOW=NA,INDICATORS=NA,PRODUCT=NA,REPORTER=NA,FREQ=NA,obsTime=NA,obsValue=NA,OBS_STATUS=NA)
}

#############################################################################################
#
# Part 2
#
# Summarise all downloaded tradeflows into one allflows.rds file and calculate net-trade etc.
#############################################################################################

rm(list=ls())
mainDir <- "~/Submissions/Commoditisation/Submission2020/Resubmission/Datainbrief_v2"
setwd(mainDir)


lastdate<-"2020-06-23"
dataset<-c("physimp","physexp","monimp","monexp")

allflows<-data.frame(PARTNER=NA,FLOW=NA,INDICATORS=NA,PRODUCT=NA,REPORTER=NA,FREQ=NA,obsTime=NA,obsValue=NA,OBS_STATUS=NA)
raw<-list(allflows,allflows,allflows,allflows)
specs<-matrix(nrow=5,ncol=5,0)
rownames(specs)<-c(dataset,"summary")
colnames(specs)<-c("obs","zeros","partuni","repuni","time")

for(i in 1:4){
  allflows<-readRDS(paste(dataset[i],lastdate,".rds",sep=""))
  allflows<-allflows[2:dim(allflows)[1],]
  
  ###date into dateformat
  allflows[,7]<-as.Date(paste(allflows[,7],"-01",sep=""),format="%Y-%m-%d")
  
  ###get rid of EU values
  allflows<-allflows[!(allflows[,1]=="EU15_EXTRA"|allflows[,1]=="EU15_INTRA"|allflows[,1]=="EU25_EXTRA"|allflows[,1]=="EU25_INTRA"|
                         allflows[,1]=="EU27_EXTRA"|allflows[,1]=="EU27_INTRA"|allflows[,1]=="EU28_EXTRA"|allflows[,1]=="EU28_INTRA"),]
  
  ###data balance and specifications
  #str(allflows)
  specs[i,1]<-dim(allflows)[1]
  specs[i,5]<-length(unique(allflows[,7])[order(as.Date(unique(allflows[,7]),format="%Y-%m-%d"))])
  specs[i,4]<-length(unique(allflows[,5]))
  specs[i,3]<-length(unique(allflows[,1]))
  specs[i,2]<-dim(allflows[allflows[,8]==0.0|allflows[,8]==0,])[1] 
  raw[[i]]<-allflows
  
}

###complete dataset using bigger (last) one
vals<-expand.grid(obsTime=unique(allflows$obsTime),
                  PARTNER=unique(allflows$PARTNER),
                  REPORTER=unique(allflows$REPORTER))

#specs[2,3]*specs[2,5]*specs[2,4]==dim(vals)[1] #TRUE!
#using last data frame (monetary exports) from the list for creating the allinone data frame 
allflows<-merge(vals,allflows,all=TRUE)
allflows[,8][is.na(allflows[,8])]<-0
allflows<-allflows[,c(1,2,3,8)]
colnames(allflows)<-c("obsTime","PARTNER","REPORTER","monexp")

#binding from raw list monitary imports
allflows<-cbind(allflows,monimp=0)
allflows$monimp<-apply(allflows,1,function(x) if(length(raw[[3]][raw[[3]]$obsTime==x[1]&raw[[3]]$PARTNER==x[2]&raw[[3]]$REPORTER==x[3],8])>0){
  raw[[3]][raw[[3]]$obsTime==x[1]&raw[[3]]$PARTNER==x[2]&raw[[3]]$REPORTER==x[3],8]
}else{0})

#binding from raw list physical exports (&conversion in tonnes)
allflows<-cbind(allflows,physexp=0)
allflows$physexp<-apply(allflows,1,function(x) if(length(raw[[2]][raw[[2]]$obsTime==x[1]&raw[[2]]$PARTNER==x[2]&raw[[2]]$REPORTER==x[3],8])>0){
  raw[[2]][raw[[2]]$obsTime==x[1]&raw[[2]]$PARTNER==x[2]&raw[[2]]$REPORTER==x[3],8]/10
}else{0})

#binding from raw list physical imports (&conversion in tonnes)
allflows<-cbind(allflows,physimp=0)
allflows$physimp<-apply(allflows,1,function(x) if(length(raw[[1]][raw[[1]]$obsTime==x[1]&raw[[1]]$PARTNER==x[2]&raw[[1]]$REPORTER==x[3],8])>0){
  raw[[1]][raw[[1]]$obsTime==x[1]&raw[[1]]$PARTNER==x[2]&raw[[1]]$REPORTER==x[3],8]/10
}else{0})

#clear out trade from REP to REP
allflows$REPORTER<-apply(allflows,1,function(x) if(as.character(x[2])==as.character(x[3])){"OUT"}else{x[3]})
allflows<-allflows[!allflows$REPORTER=="OUT",]

specs[5,1]<-dim(allflows)[1]
specs[5,5]<-length(unique(allflows[,7])[order(as.Date(unique(allflows[,1]),format="%Y-%m-%d"))])
specs[5,4]<-length(unique(allflows[,3]))
specs[5,3]<-length(unique(allflows[,2]))
specs[5,2]<-dim(allflows[allflows[,4]==0&allflows[,5]==0&allflows[,6]==0,])[1] 

#saveRDS(allflows,paste("allflows",strtrim(Sys.time(),10),".rds",sep=""))
saveRDS(specs,paste("specs",strtrim(Sys.time(),10),".rds",sep=""))

#import and export shares
allflows<-cbind(allflows,expshare=0)
allflows<-cbind(allflows,impshare=0)

allflows$expshare<-
  apply(allflows,1,function(x) round(as.numeric(x[6])/sumflows[sumflows$Group.1==x[1]&sumflows$Group.2==x[3],5],4))
allflows$expshare<-as.numeric(as.character(allflows$expshare),na.rm=T)
allflows$impshare<-
  apply(allflows,1,function(x) round(as.numeric(x[7])/sumflows[sumflows$Group.1==x[1]&sumflows$Group.2==x[3],6],4))
allflows$impshare<-as.numeric(as.character(allflows$impshare),na.rm=T)

#net-trade
allflows<-cbind(allflows,netexp=0)
allflows$netexp<-round(allflows$physexp-allflows$physimp,1)

#############################################################################################
#
# Part 3
#
# Get original pellet prices and homogenise
#############################################################################################

library(readxl)
saveDir <- mainDir
library(ggplot2)
library(plyr)
library(zoo)
library(reshape)
library(Quandl)
library(forecast)
library(urca)
library(tseries)
library(lubridate)

database <- read_excel("~/Submissions/Commoditisation/Submission2020/Resubmission/Datainbrief_v2/DB_Prices_Backup20200623.xlsx",
                       sheet = "Database", range = "A1:AP253")
identities <- read_excel("~/Submissions/Commoditisation/Submission2020/Resubmission/Datainbrief_v2/DB_Prices_Backup20200623.xlsx",
                         sheet = "Identities")

colnames(database)[1]<-"YearMonth"
database$YearMonth[1:dim(database)[1]]<-format(as.Date(seq(as.Date("2001/1/1"), by = "month", length.out = dim(database)[1])))
database$YearMonth<- as.Date(database$YearMonth)
#database$YearMonth <- format(as.Date(as.numeric(database$YearMonth)),"%Y/%m/%d")
db<-data.frame(database)

#Austrian pellet Prices cent/kWh in Euro/t with klima:aktiv conversion factor
db$TS9 <- db$TS9*4.801*10
#Austrian PPI06 into monetary values with January 2006 pellet price of 161,64 ???/t == 100
db$TS12 <- db$TS12/100*161.64

#Swedish index into monetary values and Krona to Euro
#Dez17 for 16kg Sak == 2668 SEK/t == 103.4 , for 3t == 2541 == 116.6 SEK/t for larger 15t = 349 == 94.6 SEK/MWh

db$TS17 <- db$TS17*2541/116.6
db$TS18 <- db$TS18*349/94.6*4.801
db$TS19 <- db$TS19*2668/103.4

Quandl.api_key("XXXXXX-XXXXXX") # create a free account at Quandl and enter API key here (& confirm the confirmation mail)

EURSEK<-Quandl("ECB/EURSEK", start_date = "2001-01-01")
EURSEK$Date <- format(EURSEK$Date,"%y/%m")
SEK <- aggregate(EURSEK["Value"], by = list(EURSEK$Date), function (x) mean = mean(x,na.rm=TRUE))

db$TS17[1:dim(SEK)[1]]<-db$TS17[1:dim(SEK)[1]]/SEK[,2]
db$TS18[1:dim(SEK)[1]]<-db$TS18[1:dim(SEK)[1]]/SEK[,2]
db$TS19[1:dim(SEK)[1]]<-db$TS19[1:dim(SEK)[1]]/SEK[,2]

#Swizz prices into Euro/t
EURCHF<-Quandl("ECB/EURCHF", start_date = "2001-01-01")
EURCHF$Date <- format(EURCHF$Date,"%y/%m")
CHF <- aggregate(EURCHF["Value"], by = list(EURCHF$Date), function (x) mean = mean(x,na.rm=TRUE))

db$TS20[1:dim(CHF)[1]]<-db$TS20[1:dim(CHF)[1]]/CHF[,2]
db$TS21[1:dim(CHF)[1]]<-db$TS21[1:dim(CHF)[1]]/CHF[,2]/6 #original CHF/6t

#Convert USD-values to EUR
EURUSD<-Quandl("ECB/EURUSD",start_date = "2001-01-01")
EURUSD$Date <- format(EURUSD$Date,"%y/%m")
USD <- aggregate(EURUSD["Value"], by = list(EURUSD$Date), function (x) mean = mean(x,na.rm=TRUE))

db$TS34[1:dim(USD)[1]]<-db$TS34[1:dim(USD)[1]]/USD[,2]
db$TS35[1:dim(USD)[1]]<-db$TS35[1:dim(USD)[1]]/USD[,2]
db$TS36[1:dim(USD)[1]]<-db$TS36[1:dim(USD)[1]]/USD[,2]
db$TS37[1:dim(USD)[1]]<-db$TS37[1:dim(USD)[1]]/USD[,2]
db$TS38[1:dim(USD)[1]]<-db$TS38[1:dim(USD)[1]]/USD[,2]
db$TS39[1:dim(USD)[1]]<-db$TS39[1:dim(USD)[1]]/USD[,2]
db$TS40[1:dim(USD)[1]]<-db$TS40[1:dim(USD)[1]]/USD[,2]
db$TS41[1:dim(USD)[1]]<-db$TS41[1:dim(USD)[1]]/USD[,2]

#Smooth curves where data only available all three/four months (for Italy)
db$TS13[min(which(!is.na(db$TS13))):max(which(!is.na(db$TS13)))]<-na.spline(db$TS13[min(which(!is.na(db$TS13))):max(which(!is.na(db$TS13)))])
db$TS14[min(which(!is.na(db$TS14))):max(which(!is.na(db$TS14)))]<-na.spline(db$TS14[min(which(!is.na(db$TS14))):max(which(!is.na(db$TS14)))])

#====================================================================
# Combine Time Series to create longest price TS for forecast
#====================================================================
df <- data.frame("t"=database$YearMonth)

df$AT7t <- c(db[1:48,c(8)],db[49:60,c(9)],db[61:252,c(13)])
df$DE6t <- c(db[1:108,c(4)],db[109:252,c(3)])
df$SE3t <- db$TS17
df$IT6to14t <- db$TS14
df$CH6t <- db$TS21
df$FR5t <- db$TS15
df$ARA_CIF <- db$TS34
df$US_CIF <- db$TS35
df$CA_CIF <- db$TS36
df$US_NE_FOB <- db$TS37

VAT = "incl." # incl. or excl.

#Austrian and IT original prices w/o VAT
if(VAT == "incl."){
  df$AT7t[1:180]<-df$AT7t[1:180]*1.1
  df$AT7t[181:dim(df)[1]]<-df$AT7t[181:dim(df)[1]]*1.13
  df$IT6to14t[min(which(!is.na(db$TS14))):168]<-df$IT6to14t[min(which(!is.na(db$TS14))):168]*1.1
  df$IT6to14t[169:max(which(!is.na(db$TS14)))]<-df$IT6to14t[169:max(which(!is.na(db$TS14)))]*1.22
}else{
  df$DE6t[min(which(!is.na(df$DE6t))):max(which(!is.na(df$DE6t)))] <- df$DE6t[min(which(!is.na(df$DE6t))):max(which(!is.na(df$DE6t)))]/1.07
  df$FR5t[133:156] <- df$FR5t[133:156]/1.10
  df$FR5t[157:max(which(!is.na(df$FR5t)))] <- df$FR5t[157:max(which(!is.na(df$FR5t)))]/1.07
}

prm <- df[,1:7]
folge <- c("AT","DE","SE","IT","CH","FR")
colnames(prm)<-c("months",folge)


#############################################################################################
#
# Part 4
#
# Create condensed panel data for selected flows for econometric modelling
#############################################################################################

rel<-matrix(nrow=6,ncol=3)
rel[,1]<-c("DE","IT","AT","IT","FR","IT")
rel[,2]<-c("AT","AT","DE","DE","DE","FR")
rel[,3]<-c("A","B","C","D","E","F")

pnl<-allflows[allflows$PARTNER==rel[1,1]&allflows$REPORTER==rel[1,2],]
for(i in 2:6){
  pnl<-rbind(pnl,allflows[allflows$PARTNER==rel[i,1]&allflows$REPORTER==rel[i,2],])
}

pnl<-cbind(pnl,PARimpshare=0)
pnl$PARimpshare<-apply(pnl,1,function(x) allflows[allflows$obsTime==x[1]&allflows$PARTNER==x[3]&allflows$REPORTER==x[2],]$impshare)

#bind non-eurostat data to pnl
pnl<-cbind(pnl,PAR=0)
pnl<-cbind(pnl,REP=0)
pnl$PAR<-apply(pnl,1,function(x) as.numeric(prm[prm$month==x[1],1+which(folge==x[2])]))
pnl$REP<-apply(pnl,1,function(x) as.numeric(prm[prm$month==x[1],1+which(folge==x[3])]))

#bind dummy for flows
pnl<-cbind(pnl,flw=0)
pnl$flw<-apply(pnl,1,function(x) rel[rel[,1]==x[2]&rel[,2]==x[3],3])

###########################
saveRDS(sumflows,paste("sumflows",strtrim(Sys.time(),10),".rds",sep=""))
saveRDS(allflows,paste("eurostat",strtrim(Sys.time(),10),".rds",sep=""))
saveRDS(pnl,paste("focusset",strtrim(Sys.time(),10),".rds",sep=""))

prm <- prm[,c(1,2,3,5,7)]
saveRDS(prm,paste("pricesTS",strtrim(Sys.time(),10),".rds",sep=""))

#############################################################################################
#
# Part 5
#
# First analysis for the written part in the manuscript 
#############################################################################################
#Jan2012 bis incl. Nov2018 = 7*12-1 = 83Months
#Jan2012 bis incl. Mar2020

unique(a$obsTime) # 100 timesteps incl. April 2020


'%ni%' <- Negate('%in%')
a <- allflows[allflows$PARTNER %ni% c("EA19_EXTRA","EA19_INTRA","EU27_2020_EXTRA","EU27_2020_INTRA","EUROZONE_EXTRA","EUROZONE_INTRA","EU_EXTRA","EU_INTRA"),]
aggregate(a[a$REPORTER == "IT",]$physimp, by=list(a[a$REPORTER == "IT",]$PARTNER), FUN = sum)

sum(a[a$REPORTER == "IT",]$physimp)/1000000
sum(a[a$REPORTER == "DE",]$physimp)/1000000
sum(a[a$REPORTER == "AT",]$physimp)/1000000
sum(a[a$REPORTER == "FR",]$physimp)/1000000

sum(a[a$REPORTER == "IT"&a$PARTNER %in% c("DE","AT","FR"),]$physimp)/sum(a[a$REPORTER == "IT",]$physimp)
sum(a[a$REPORTER == "FR"&a$PARTNER %in% c("DE","AT","IT"),]$physimp)/sum(a[a$REPORTER == "FR",]$physimp)
sum(a[a$REPORTER == "AT"&a$PARTNER %in% c("DE","FR","IT"),]$physimp)/sum(a[a$REPORTER == "AT",]$physimp)
sum(a[a$REPORTER == "DE"&a$PARTNER %in% c("FR","AT","IT"),]$physimp)/sum(a[a$REPORTER == "DE",]$physimp)


sum(allflows[allflows$REPORTER == "AT"&allflows$PARTNER %in% c("DE"),]$physimp)
sum(allflows[allflows$REPORTER == "DE"&allflows$PARTNER %in% c("AT"),]$physexp)
sum(allflows[allflows$REPORTER == "AT"&allflows$PARTNER %in% c("DE"),]$physexp)
sum(allflows[allflows$REPORTER == "AT"&allflows$PARTNER %in% c("IT"),]$physexp)/1000000
sum(allflows[allflows$REPORTER == "DE"&allflows$PARTNER %in% c("IT"),]$physexp)/1000
sum(allflows[allflows$REPORTER == "FR"&allflows$PARTNER %in% c("IT"),]$physexp)/1000
sum(allflows[allflows$REPORTER == "DE"&allflows$PARTNER %in% c("FR"),]$physexp)/1000

sum(allflows[allflows$REPORTER == "AT"&allflows$PARTNER %in% c("DE"),]$netexp)
sum(allflows[allflows$REPORTER == "DE"&allflows$PARTNER %in% c("AT"),]$netexp)

############################################################## End of Data Collection & Preparation 2020 v2 ########################################
